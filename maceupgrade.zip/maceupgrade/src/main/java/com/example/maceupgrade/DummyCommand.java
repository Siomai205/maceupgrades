package com.example.maceupgrade;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.exceptions.CommandSyntaxException;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/**
 * /dummy        spawns a PvP dummy 3 blocks in front of you
 * /dummy clear  removes the dummies this command spawned
 *
 * With Carpet installed, the dummy is a Carpet fake player (runs /player <name> spawn),
 * so killing it counts as a real player kill for mace upgrades. The max-tier ban is
 * skipped for these dummies. Without Carpet it falls back to a no-AI Husk with 1000 HP
 * (killing that does NOT count toward upgrades).
 *
 * Every hit you land on a dummy shows the damage dealt in your action bar.
 */
public final class DummyCommand {
	private static final String HUSK_TAG = "pvpdummy";
	private static final String BOT_PREFIX = "Dummy";

	private static final String HUSK_NBT = "{NoAI:1b,Silent:1b,PersistenceRequired:1b,CanPickUpLoot:0b,"
		+ "CustomName:\"PvP Dummy\",CustomNameVisible:1b,Tags:[\"" + HUSK_TAG + "\"],"
		+ "DeathLootTable:\"minecraft:empty\","
		+ "attributes:[{id:\"minecraft:max_health\",base:1000.0d}],Health:1000.0f,"
		+ "active_effects:[{id:\"minecraft:regeneration\",amplifier:4,duration:-1,show_particles:0b}]}";

	/** Names of Carpet fake players spawned by /dummy (this session). */
	private static final List<String> BOTS = new ArrayList<>();
	private static int counter = 0;

	private DummyCommand() {}

	/** True if this player name is a dummy spawned by /dummy. */
	public static boolean isDummy(String name) {
		for (String bot : BOTS) {
			if (bot.equalsIgnoreCase(name)) {
				return true;
			}
		}
		return false;
	}

	public static void register() {
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
			dispatcher.register(CommandManager.literal("dummy")
				.executes(ctx -> spawn(ctx.getSource()))
				.then(CommandManager.literal("clear")
					.executes(ctx -> clear(ctx.getSource())))));

		// Show the damage you deal to a dummy.
		ServerLivingEntityEvents.AFTER_DAMAGE.register((entity, source, baseDamageTaken, damageTaken, blocked) -> {
			if (!(source.getAttacker() instanceof ServerPlayerEntity attacker)) {
				return;
			}
			boolean isDummy = entity.getCommandTags().contains(HUSK_TAG)
				|| (entity instanceof ServerPlayerEntity p && isDummy(p.getName().getString()));
			if (isDummy) {
				attacker.sendMessage(Text.literal(String.format(Locale.ROOT, "Damage dealt: %.1f", damageTaken))
					.formatted(Formatting.RED, Formatting.BOLD), true);
			}
		});
	}

	private static int spawn(ServerCommandSource source) {
		ServerPlayerEntity player = source.getPlayer();
		if (player == null) {
			source.sendError(Text.literal("Only players can use /dummy."));
			return 0;
		}
		MinecraftServer server = source.getServer();
		// Run as the player (their position, dimension and facing), with the server's permissions.
		String at = "execute as " + player.getUuidAsString() + " at @s rotated ~ 0 positioned ^ ^ ^3 run ";

		String name = BOT_PREFIX + (++counter);
		// Try Carpet first. The extra "in survival" makes sure the bot can be damaged.
		if (run(server, at + "player " + name + " spawn in survival")
			|| run(server, at + "player " + name + " spawn")) {
			BOTS.add(name);
			source.sendFeedback(() -> Text.literal("Spawned Carpet dummy " + name + ". Use /dummy clear to remove it.")
				.formatted(Formatting.GREEN), false);
			return Command.SINGLE_SUCCESS;
		}

		// Carpet is not installed: fall back to a Husk dummy.
		if (run(server, at + "summon minecraft:husk ~ ~ ~ " + HUSK_NBT)) {
			source.sendFeedback(() -> Text.literal("Carpet not found, spawned a Husk dummy instead. "
				+ "(Husk kills do not count for mace upgrades.)").formatted(Formatting.YELLOW), false);
			return Command.SINGLE_SUCCESS;
		}
		source.sendError(Text.literal("Could not spawn the dummy."));
		return 0;
	}

	private static int clear(ServerCommandSource source) {
		ServerPlayerEntity player = source.getPlayer();
		if (player == null) {
			source.sendError(Text.literal("Only players can use /dummy."));
			return 0;
		}
		MinecraftServer server = source.getServer();
		for (String bot : new ArrayList<>(BOTS)) {
			run(server, "player " + bot + " kill");
		}
		BOTS.clear();
		run(server, "execute as " + player.getUuidAsString()
			+ " at @s run kill @e[type=minecraft:husk,tag=" + HUSK_TAG + ",distance=..50]");
		source.sendFeedback(() -> Text.literal("Removed PvP dummies.").formatted(Formatting.YELLOW), false);
		return Command.SINGLE_SUCCESS;
	}

	private static boolean run(MinecraftServer server, String command) {
		try {
			server.getCommandManager().getDispatcher().execute(command, server.getCommandSource());
			return true;
		} catch (CommandSyntaxException e) {
			return false;
		}
	}
}
