package com.example.maceupgrade;

import java.util.ArrayList;
import java.util.List;

import com.mojang.brigadier.exceptions.CommandSyntaxException;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifierSlot;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

/**
 * Kill a player while holding a mace and the mace upgrades.
 *
 * 5 upgrade tiers. The kills needed for each upgrade multiply by themselves:
 *   upgrade 1 = 1x1 = 1 kill, 2 = 2x2 = 4, 3 = 3x3 = 9, 4 = 4x4 = 16, 5 = 5x5 = 25.
 * Kills count toward the next upgrade only, and reset after each upgrade.
 *
 * Each upgrade: new texture, stronger enchantments, more damage, more abilities.
 * At max tier, every player the mace kills gets banned (see BAN_ON_KILL below).
 */
public class MaceUpgradeMod implements ModInitializer {
	public static final int MAX_TIER = 5;
	private static final double BONUS_DAMAGE_PER_TIER = 3.0;

	/** Set to false to disable the ban ability of the max-tier mace. */
	private static final boolean BAN_ON_KILL = true;

	private static final String[] NAMES = {
		"Mace", "Copper Mace", "Iron Mace", "Golden Mace", "Diamond Mace", "Netherite Mace"
	};
	private static final Formatting[] COLORS = {
		Formatting.WHITE, Formatting.GOLD, Formatting.GRAY, Formatting.YELLOW, Formatting.AQUA, Formatting.DARK_PURPLE
	};

	private static MinecraftServer server;

	@Override
	public void onInitialize() {
		ServerLifecycleEvents.SERVER_STARTED.register(s -> server = s);
		ServerLifecycleEvents.SERVER_STOPPED.register(s -> server = null);

		MaceAbilities.register();

		ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
			if (!(entity instanceof ServerPlayerEntity victim)) {
				return;
			}
			if (!(source.getAttacker() instanceof ServerPlayerEntity killer) || killer == victim) {
				return;
			}
			ItemStack mace = killer.getMainHandStack();
			if (!mace.isOf(Items.MACE)) {
				return;
			}
			handleKill(killer, victim, mace);
		});
	}

	private static void handleKill(ServerPlayerEntity killer, ServerPlayerEntity victim, ItemStack mace) {
		NbtComponent existing = mace.get(DataComponentTypes.CUSTOM_DATA);
		NbtCompound data = existing == null ? new NbtCompound() : existing.copyNbt();

		int tier = data.getInt("mace_tier", 0);
		int kills = data.getInt("mace_kills", 0);

		if (tier >= MAX_TIER) {
			// Final-tier ability: the victim is banned.
			if (BAN_ON_KILL) {
				banPlayer(killer, victim);
			}
			killer.sendMessage(Text.literal("Your Netherite Mace banned " + victim.getName().getString() + "!")
				.formatted(Formatting.LIGHT_PURPLE), true);
			return;
		}

		kills++;
		int needed = killsNeeded(tier + 1);

		if (kills >= needed) {
			tier++;
			kills = 0;
			killer.playSound(SoundEvents.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
			killer.sendMessage(Text.literal("Your mace upgraded to " + NAMES[tier] + "! (Tier " + tier + "/" + MAX_TIER + ")")
				.formatted(COLORS[tier], Formatting.BOLD), true);
		} else {
			killer.sendMessage(Text.literal("Mace progress: " + kills + "/" + needed + " kills")
				.formatted(Formatting.GREEN), true);
		}

		data.putInt("mace_tier", tier);
		data.putInt("mace_kills", kills);
		mace.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(data));

		applyTier(killer, mace, tier, kills);
	}

	private static void banPlayer(ServerPlayerEntity killer, ServerPlayerEntity victim) {
		if (server == null) {
			return;
		}
		String reason = "Killed by " + killer.getName().getString() + "'s Netherite Mace";
		try {
			// Runs the vanilla /ban command as the server, so it works on dedicated and LAN servers.
			server.getCommandManager().getDispatcher()
				.execute("ban " + victim.getName().getString() + " " + reason, server.getCommandSource());
		} catch (CommandSyntaxException e) {
			killer.sendMessage(Text.literal("Ban failed: " + e.getMessage()).formatted(Formatting.RED), false);
		}
	}

	/** Kills needed to reach the given upgrade: the number multiplied by itself. */
	public static int killsNeeded(int upgradeNumber) {
		return upgradeNumber * upgradeNumber;
	}

	private static void applyTier(ServerPlayerEntity owner, ItemStack mace, int tier, int kills) {
		// Vanilla mace: +5 attack damage (6 total with base 1), -3.4 attack speed.
		AttributeModifiersComponent attributes = AttributeModifiersComponent.builder()
			.add(EntityAttributes.ATTACK_DAMAGE,
				new EntityAttributeModifier(Identifier.ofVanilla("base_attack_damage"),
					5.0 + tier * BONUS_DAMAGE_PER_TIER, EntityAttributeModifier.Operation.ADD_VALUE),
				AttributeModifierSlot.MAINHAND)
			.add(EntityAttributes.ATTACK_SPEED,
				new EntityAttributeModifier(Identifier.ofVanilla("base_attack_speed"),
					-3.4, EntityAttributeModifier.Operation.ADD_VALUE),
				AttributeModifierSlot.MAINHAND)
			.build();
		mace.set(DataComponentTypes.ATTRIBUTE_MODIFIERS, attributes);

		if (tier > 0) {
			mace.set(DataComponentTypes.CUSTOM_NAME,
				Text.literal(NAMES[tier]).styled(s -> s.withItalic(false)).formatted(COLORS[tier]));
			mace.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
			// Each tier has its own texture (assets/maceupgrade/items/mace_tier_N.json).
			mace.set(DataComponentTypes.ITEM_MODEL, Identifier.of("maceupgrade", "mace_tier_" + tier));
			applyEnchantments(owner.getRegistryManager(), mace, tier);
		}

		List<Text> lore = new ArrayList<>();
		lore.add(Text.literal("Tier " + tier + "/" + MAX_TIER).styled(s -> s.withItalic(false)).formatted(COLORS[tier]));
		if (tier >= MAX_TIER) {
			lore.add(Text.literal("MAX TIER").styled(s -> s.withItalic(false)).formatted(Formatting.LIGHT_PURPLE));
		} else {
			lore.add(Text.literal("Next upgrade: " + kills + "/" + killsNeeded(tier + 1) + " player kills")
				.styled(s -> s.withItalic(false)).formatted(Formatting.GRAY));
		}
		for (String ability : MaceAbilities.describe(tier)) {
			lore.add(Text.literal(ability).styled(s -> s.withItalic(false)).formatted(Formatting.DARK_AQUA));
		}
		mace.set(DataComponentTypes.LORE, new LoreComponent(lore));
	}

	/**
	 * Enchantments by tier:
	 *   1: Unbreaking I
	 *   2: Unbreaking II, Density I
	 *   3: Unbreaking III, Density II, Fire Aspect I
	 *   4: Unbreaking III, Density III, Breach I, Fire Aspect I
	 *   5: Unbreaking III, Density V, Breach IV, Wind Burst III, Mending, Fire Aspect II
	 */
	private static void applyEnchantments(DynamicRegistryManager registries, ItemStack mace, int tier) {
		var enchants = registries.getOrThrow(RegistryKeys.ENCHANTMENT);
		EnchantmentHelper.apply(mace, builder -> {
			add(builder, enchants.getOrThrow(Enchantments.UNBREAKING), Math.min(tier, 3));
			if (tier >= 2) add(builder, enchants.getOrThrow(Enchantments.DENSITY), new int[] {0, 0, 1, 2, 3, 5}[tier]);
			if (tier >= 3) add(builder, enchants.getOrThrow(Enchantments.FIRE_ASPECT), tier >= 5 ? 2 : 1);
			if (tier >= 4) add(builder, enchants.getOrThrow(Enchantments.BREACH), new int[] {0, 0, 0, 0, 1, 4}[tier]);
			if (tier >= 5) {
				add(builder, enchants.getOrThrow(Enchantments.WIND_BURST), 3);
				add(builder, enchants.getOrThrow(Enchantments.MENDING), 1);
			}
		});
	}

	private static void add(net.minecraft.component.type.ItemEnchantmentsComponent.Builder builder,
							net.minecraft.registry.entry.RegistryEntry<Enchantment> enchantment, int level) {
		builder.add(enchantment, level);
	}
}
