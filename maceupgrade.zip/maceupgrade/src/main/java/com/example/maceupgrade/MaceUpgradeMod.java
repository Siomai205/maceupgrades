package com.example.maceupgrade;

import java.util.ArrayList;
import java.util.List;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifierSlot;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.item.Items;
import net.minecraft.item.MaceItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

public class MaceUpgradeMod implements ModInitializer {
    public static final String MOD_ID = "lettherebemoremaces";
    public static final int MAX_TIER = 5;
    private static final double BONUS_DAMAGE_PER_TIER = 3.0;
    private static final String[] NAMES = {"Mace", "Copper Mace", "Iron Mace", "Golden Mace", "Diamond Mace", "Netherite Mace"};
    private static final Formatting[] COLORS = {Formatting.WHITE, Formatting.GOLD, Formatting.GRAY, Formatting.YELLOW, Formatting.AQUA, Formatting.DARK_PURPLE};

    public static final Item WARDEN_HEAVY_CORE = register("warden_heavy_core");
    public static final Item ENDER_HEAVY_CORE = register("ender_heavy_core");
    public static final Item NETHER_HEAVY_CORE = register("nether_heavy_core");
    public static final Item WARDEN_MACE = registerMace("warden_mace");
    public static final Item ENDER_MACE = registerMace("ender_mace");
    public static final Item NETHER_MACE = registerMace("nether_mace");

    private static Item register(String name) {
        Identifier id = Identifier.of(MOD_ID, name);
        RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, id);
        return Registry.register(Registries.ITEM, id, new Item(new Item.Settings().registryKey(key).maxCount(64)));
    }

    private static Item registerMace(String name) {
        Identifier id = Identifier.of(MOD_ID, name);
        RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, id);
        return Registry.register(Registries.ITEM, id, new MaceItem(new Item.Settings().registryKey(key).maxCount(1).fireproof()));
    }

    @Override
    public void onInitialize() {
        MaceAbilities.register();
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (!(source.getAttacker() instanceof ServerPlayerEntity killer)) return;
            ItemStack held = killer.getMainHandStack();
            if (!held.isOf(Items.MACE)) return;
            handleKill(killer, held);
        });
    }

    private static void handleKill(ServerPlayerEntity killer, ItemStack mace) {
        NbtComponent existing = mace.get(DataComponentTypes.CUSTOM_DATA);
        net.minecraft.nbt.NbtCompound data = existing == null ? new net.minecraft.nbt.NbtCompound() : existing.copyNbt();
        int tier = data.getInt("mace_tier", 0);
        int kills = data.getInt("mace_kills", 0);
        if (tier >= MAX_TIER) return;
        kills++;
        int needed = killsNeeded(tier + 1);
        if (kills >= needed) {
            tier++;
            kills = 0;
            killer.playSound(SoundEvents.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
            killer.sendMessage(Text.literal("Your mace upgraded to " + NAMES[tier] + "! (Tier " + tier + "/" + MAX_TIER + ")")
                    .formatted(COLORS[tier], Formatting.BOLD), true);
        } else {
            killer.sendMessage(Text.literal("Mace progress: " + kills + "/" + needed + " kills")
                    .formatted(Formatting.GREEN), true);
        }
        data.putInt("mace_tier", tier);
        data.putInt("mace_kills", kills);
        mace.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(data));
        applyTier(killer, mace, tier, kills);
    }

    public static int killsNeeded(int upgradeNumber) { return upgradeNumber * upgradeNumber; }

    private static void applyTier(ServerPlayerEntity owner, ItemStack mace, int tier, int kills) {
        AttributeModifiersComponent attributes = AttributeModifiersComponent.builder()
                .add(EntityAttributes.ATTACK_DAMAGE, new EntityAttributeModifier(Identifier.ofVanilla("base_attack_damage"),
                        5.0 + tier * BONUS_DAMAGE_PER_TIER, EntityAttributeModifier.Operation.ADD_VALUE), AttributeModifierSlot.MAINHAND)
                .add(EntityAttributes.ATTACK_SPEED, new EntityAttributeModifier(Identifier.ofVanilla("base_attack_speed"),
                        -3.4, EntityAttributeModifier.Operation.ADD_VALUE), AttributeModifierSlot.MAINHAND).build();
        mace.set(DataComponentTypes.ATTRIBUTE_MODIFIERS, attributes);
        if (tier > 0) {
            mace.set(DataComponentTypes.CUSTOM_NAME, Text.literal(NAMES[tier]).styled(s -> s.withItalic(false)).formatted(COLORS[tier]));
            mace.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
            mace.set(DataComponentTypes.ITEM_MODEL, Identifier.of(MOD_ID, "mace_tier_" + tier));
            applyEnchantments(owner.getRegistryManager(), mace, tier);
        }
        List<Text> lore = new ArrayList<>();
        lore.add(Text.literal("Tier " + tier + "/" + MAX_TIER).styled(s -> s.withItalic(false)).formatted(COLORS[tier]));
        if (tier >= MAX_TIER) lore.add(Text.literal("MAX TIER").styled(s -> s.withItalic(false)).formatted(Formatting.LIGHT_PURPLE));
        else lore.add(Text.literal("Next upgrade: " + kills + "/" + killsNeeded(tier + 1) + " kills").styled(s -> s.withItalic(false)).formatted(Formatting.GRAY));
        for (String ability : MaceAbilities.describe(tier)) lore.add(Text.literal(ability).styled(s -> s.withItalic(false)).formatted(Formatting.DARK_AQUA));
        mace.set(DataComponentTypes.LORE, new LoreComponent(lore));
    }
    private static void applyEnchantments(DynamicRegistryManager registries, ItemStack mace, int tier) {
        var enchants = registries.getOrThrow(RegistryKeys.ENCHANTMENT);
        EnchantmentHelper.apply(mace, builder -> {
            add(builder, enchants.getOrThrow(Enchantments.UNBREAKING), Math.min(tier, 3));
            if (tier >= 2) add(builder, enchants.getOrThrow(Enchantments.DENSITY), new int[] {0, 0, 1, 2, 3, 5}[tier]);
            if (tier >= 3) add(builder, enchants.getOrThrow(Enchantments.FIRE_ASPECT), tier >= 5 ? 2 : 1);
            if (tier >= 4) add(builder, enchants.getOrThrow(Enchantments.BREACH), new int[] {0, 0, 0, 0, 1, 4}[tier]);
            if (tier >= 5) {
                add(builder, enchants.getOrThrow(Enchantments.WIND_BURST), 3);
                add(builder, enchants.getOrThrow(Enchantments.MENDING), 1);
            }
        });
    }

    private static void add(ItemEnchantmentsComponent.Builder builder, RegistryEntry<Enchantment> enchantment, int level) {
        builder.add(enchantment, level);
    }

}
