package com.example.maceupgrade;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.boss.WitherEntity;
import net.minecraft.entity.boss.dragon.EnderDragonEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.WardenEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.screen.CraftingScreenHandler;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

/**
 * The three boss maces: Warden, Ender and Nether (Wither).
 *
 * They are separate from the kill-upgrade maces. They do not level up. Each one is
 * crafted (heavy core first, then the mace) and each has passive effects, on-hit
 * effects and two active abilities:
 *   right-click           = ability 1
 *   sneak + right-click   = ability 2
 *
 * Quests (each unlocks crafting for that mace and its heavy core):
 *   Warden: kill a Warden       tag maces_quest_warden
 *   Ender:  kill the Ender Dragon   tag maces_quest_ender
 *   Nether: kill the Wither     tag maces_quest_nether
 * Ops can also unlock one with: /tag <player> add maces_quest_warden
 *
 * The locked recipes are blocked in code: if the crafting result carries quest data
 * and the player does not have the quest tag, the result slot is emptied.
 */
public final class ThemedMaces {
	private static final String QUEST_TAG = "maces_quest_";
	private static final String NS = "maceupgrade";

	private ThemedMaces() {}

	public static void register() {
		// --- per-tick: crafting lock every tick, passive effects + inventory sweep every second
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
				gateCrafting(p);
				if (server.getTicks() % 20 == 0) {
					passives(p);
					sweepLockedItems(p);
				}
			}
		});

		// --- on-hit effects (melee with the mace itself)
		ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
			if (source.getAttacker() instanceof ServerPlayerEntity attacker
				&& source.getSource() == attacker
				&& entity != attacker) {
				String type = typeOf(attacker.getMainHandStack());
				if (type.equals("warden")) {
					entity.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 100, 0));
					entity.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 40, 0));
				} else if (type.equals("ender")) {
					entity.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 40, 0));
					entity.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 80, 0));
					if (Math.random() < 0.25) {
						// Enderman: the victim is thrown a few blocks away.
						run("execute as " + entity.getUuidAsString() + " at @s run spreadplayers ~ ~ 2 8 false @s");
					}
				} else if (type.equals("nether")) {
					entity.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 120, 1));
					entity.setOnFireFor(4);
				}
			}
			return true;
		});

		// --- active abilities
		UseItemCallback.EVENT.register((player, world, hand) -> {
			if (hand != Hand.MAIN_HAND || !(player instanceof ServerPlayerEntity sp)) {
				return ActionResult.PASS;
			}
			ItemStack stack = sp.getMainHandStack();
			String type = typeOf(stack);
			if (type.isEmpty() || sp.getItemCooldownManager().isCoolingDown(stack)) {
				return ActionResult.PASS;
			}
			boolean sneak = sp.isSneaking();
			int cooldown;
			if (type.equals("warden")) {
				cooldown = sneak ? sculkShriek(sp) : sonicBoom(sp);
			} else if (type.equals("ender")) {
				cooldown = sneak ? dragonBreath(sp) : enderBlink(sp);
			} else if (type.equals("nether")) {
				cooldown = sneak ? witheringBlast(sp) : witherVolley(sp);
			} else {
				return ActionResult.PASS;
			}
			sp.getItemCooldownManager().set(stack, cooldown);
			return ActionResult.SUCCESS;
		});

		// --- quests
		ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
			if (!(source.getAttacker() instanceof ServerPlayerEntity killer)) {
				return;
			}
			String quest = "";
			if (entity instanceof WardenEntity) {
				quest = "warden";
			} else if (entity instanceof EnderDragonEntity) {
				quest = "ender";
			} else if (entity instanceof WitherEntity) {
				quest = "nether";
			}
			if (!quest.isEmpty()) {
				completeQuest(killer, quest);
			}
		});

		// --- /maces and /maces quests
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
			dispatcher.register(CommandManager.literal("maces")
				.executes(ctx -> showQuests(ctx.getSource()))
				.then(CommandManager.literal("quests")
					.executes(ctx -> showQuests(ctx.getSource())))));
	}

	// ------------------------------------------------------------------ helpers

	/** "warden", "ender", "nether", or "" if this is not a boss mace. */
	static String typeOf(ItemStack stack) {
		if (stack.isEmpty() || !stack.isOf(Items.MACE)) {
			return "";
		}
		NbtComponent data = stack.get(DataComponentTypes.CUSTOM_DATA);
		return data == null ? "" : data.copyNbt().getString("mace_type", "");
	}

	/** The quest an item is locked behind, or "". */
	static String questOf(ItemStack stack) {
		if (stack.isEmpty()) {
			return "";
		}
		NbtComponent data = stack.get(DataComponentTypes.CUSTOM_DATA);
		return data == null ? "" : data.copyNbt().getString("quest", "");
	}

	private static boolean hasQuest(ServerPlayerEntity p, String quest) {
		return p.getCommandTags().contains(QUEST_TAG + quest);
	}

	private static String questName(String quest) {
		switch (quest) {
			case "warden": return "Warden";
			case "ender": return "Ender";
			default: return "Nether";
		}
	}

	private static String questGoal(String quest) {
		switch (quest) {
			case "warden": return "Kill a Warden";
			case "ender": return "Defeat the Ender Dragon";
			default: return "Defeat the Wither";
		}
	}

	/** Runs a command as the server, silently. Returns false if it failed. */
	private static boolean run(String command) {
		MinecraftServer server = MaceUpgradeMod.server();
		if (server == null) {
			return false;
		}
		try {
			server.getCommandManager().getDispatcher().execute(command, server.getCommandSource().withSilent());
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	private static void give(ServerPlayerEntity p, RegistryEntry<StatusEffect> effect, int amplifier) {
		p.addStatusEffect(new StatusEffectInstance(effect, 300, amplifier, true, false, true));
	}

	private static void passives(ServerPlayerEntity p) {
		String type = typeOf(p.getMainHandStack());
		if (type.equals("warden")) {
			give(p, StatusEffects.NIGHT_VISION, 0);
			give(p, StatusEffects.RESISTANCE, 1);
		} else if (type.equals("ender")) {
			give(p, StatusEffects.SPEED, 1);
			give(p, StatusEffects.JUMP_BOOST, 0);
		} else if (type.equals("nether")) {
			give(p, StatusEffects.FIRE_RESISTANCE, 0);
			give(p, StatusEffects.STRENGTH, 1);
		}
	}

	// ------------------------------------------------------------------ crafting lock

	private static void gateCrafting(ServerPlayerEntity p) {
		ScreenHandler handler = p.currentScreenHandler;
		if (!(handler instanceof CraftingScreenHandler) && !(handler instanceof PlayerScreenHandler)) {
			return;
		}
		Slot out = handler.getSlot(0);
		String quest = questOf(out.getStack());
		if (quest.isEmpty() || hasQuest(p, quest)) {
			return;
		}
		out.setStack(ItemStack.EMPTY);
		handler.sendContentUpdates();
		p.sendMessage(Text.literal("Locked! Quest needed: " + questGoal(quest) + ". See /maces quests")
			.formatted(Formatting.RED), true);
	}

	/** Backstop: removes locked items from players who have not done the quest. */
	private static void sweepLockedItems(ServerPlayerEntity p) {
		PlayerInventory inv = p.getInventory();
		for (int i = 0; i < inv.size(); i++) {
			String quest = questOf(inv.getStack(i));
			if (!quest.isEmpty() && !hasQuest(p, quest)) {
				inv.setStack(i, ItemStack.EMPTY);
				p.sendMessage(Text.literal("A locked mace item was removed. Quest needed: " + questGoal(quest))
					.formatted(Formatting.RED), false);
			}
		}
	}

	// ------------------------------------------------------------------ quests

	private static void completeQuest(ServerPlayerEntity p, String quest) {
		if (hasQuest(p, quest)) {
			return;
		}
		p.addCommandTag(QUEST_TAG + quest);
		String id = p.getUuidAsString();
		run("recipe give " + id + " " + NS + ":" + quest + "_heavy_core " + NS + ":" + quest + "_mace");
		String name = questName(quest);
		p.sendMessage(Text.literal("QUEST COMPLETE: " + questGoal(quest) + "!")
			.formatted(Formatting.GOLD, Formatting.BOLD), false);
		p.sendMessage(Text.literal("You can now craft the " + name + " Heavy Core and the " + name + " Mace.")
			.formatted(Formatting.YELLOW), false);
	}

	private static int showQuests(ServerCommandSource source) {
		ServerPlayerEntity p = source.getPlayer();
		if (p == null) {
			source.sendError(Text.literal("Only players can use /maces."));
			return 0;
		}
		source.sendFeedback(() -> Text.literal("--- Let There Be More Maces: quests ---").formatted(Formatting.GOLD), false);
		for (String quest : new String[] {"warden", "ender", "nether"}) {
			boolean done = hasQuest(p, quest);
			String line = (done ? "[DONE] " : "[    ] ") + questName(quest) + " Mace: " + questGoal(quest);
			source.sendFeedback(() -> Text.literal(line).formatted(done ? Formatting.GREEN : Formatting.GRAY), false);
		}
		source.sendFeedback(() -> Text.literal("Craft a boss heavy core, then combine it with a breeze rod and the boss item.")
			.formatted(Formatting.YELLOW), false);
		return 1;
	}

	// ------------------------------------------------------------------ Warden abilities

	private static final String TARGETS_NEAR =
		"[type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:area_effect_cloud]";

	/** Right-click: a sonic boom down the line you are looking at. */
	private static int sonicBoom(ServerPlayerEntity p) {
		String id = p.getUuidAsString();
		run("execute as " + id + " at @s run playsound minecraft:entity.warden.sonic_boom hostile @a ~ ~ ~ 3");
		for (int d = 3; d <= 15; d += 3) {
			String at = "execute as " + id + " at @s anchored eyes positioned ^ ^ ^" + d + " ";
			run(at + "run particle minecraft:sonic_boom ~ ~ ~ 0 0 0 0 1 force");
			run(at + "as @e[distance=..2.2,type=!minecraft:item,type=!minecraft:experience_orb] run damage @s 10 minecraft:sonic_boom by " + id);
		}
		return 160;
	}

	/** Sneak + right-click: a roar that blinds and weakens everything near you. */
	private static int sculkShriek(ServerPlayerEntity p) {
		String id = p.getUuidAsString();
		String near = "@e[distance=0.1..12,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:area_effect_cloud]";
		run("execute as " + id + " at @s run playsound minecraft:entity.warden.roar hostile @a ~ ~ ~ 3");
		run("execute as " + id + " at @s run particle minecraft:sculk_soul ~ ~1 ~ 3 1 3 0.05 80 force");
		run("execute as " + id + " at @s run effect give " + near + " minecraft:darkness 10 0 true");
		run("execute as " + id + " at @s run effect give " + near + " minecraft:slowness 6 1 true");
		run("execute as " + id + " at @s run effect give " + near + " minecraft:weakness 8 0 true");
		run("effect give " + id + " minecraft:strength 8 1 true");
		return 400;
	}

	// ------------------------------------------------------------------ Ender abilities

	/** Right-click: teleport up to 14 blocks forward (like an Enderman). */
	private static int enderBlink(ServerPlayerEntity p) {
		String id = p.getUuidAsString();
		double x = p.getX();
		double y = p.getY();
		double z = p.getZ();
		run("execute as " + id + " at @s run particle minecraft:portal ~ ~1 ~ 0.3 0.6 0.3 0.4 60 force");
		boolean moved = false;
		for (int d = 14; d >= 2 && !moved; d--) {
			run("execute as " + id + " at @s rotated ~ 0 positioned ^ ^ ^" + d
				+ " if block ~ ~ ~ minecraft:air if block ~ ~1 ~ minecraft:air run tp @s ~ ~ ~");
			moved = p.getX() != x || p.getY() != y || p.getZ() != z;
		}
		if (!moved) {
			p.sendMessage(Text.literal("No room to blink there.").formatted(Formatting.GRAY), true);
			return 10;
		}
		run("execute as " + id + " at @s run playsound minecraft:entity.enderman.teleport player @a ~ ~ ~ 1");
		run("execute as " + id + " at @s run particle minecraft:portal ~ ~1 ~ 0.3 0.6 0.3 0.4 60 force");
		run("effect give " + id + " minecraft:slow_falling 2 0 true");
		return 60;
	}

	/** Sneak + right-click: Dragon's Breath burst around you, and a wing-beat upward. */
	private static int dragonBreath(ServerPlayerEntity p) {
		String id = p.getUuidAsString();
		String near = "@e[distance=0.1..7,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:area_effect_cloud]";
		run("execute as " + id + " at @s run playsound minecraft:entity.ender_dragon.growl hostile @a ~ ~ ~ 3");
		run("execute as " + id + " at @s run particle minecraft:dragon_breath ~ ~0.5 ~ 3 0.5 3 0.03 250 force");
		run("execute as " + id + " at @s run particle minecraft:portal ~ ~1 ~ 3 1 3 0.3 150 force");
		run("execute as " + id + " at @s as " + near + " run damage @s 8 minecraft:dragon_breath by " + id);
		run("execute as " + id + " at @s run effect give " + near + " minecraft:slowness 5 1 true");
		run("execute as " + id + " at @s run effect give " + near + " minecraft:weakness 6 0 true");
		Vec3d v = p.getVelocity();
		p.setVelocity(v.x, 1.1, v.z);
		p.networkHandler.sendPacket(new EntityVelocityUpdateS2CPacket(p));
		p.fallDistance = 0;
		return 300;
	}

	// ------------------------------------------------------------------ Nether (Wither) abilities

	/** Right-click: a volley of wither damage along your line of sight. */
	private static int witherVolley(ServerPlayerEntity p) {
		String id = p.getUuidAsString();
		run("execute as " + id + " at @s run playsound minecraft:entity.wither.shoot hostile @a ~ ~ ~ 2");
		for (int d = 3; d <= 18; d += 3) {
			String at = "execute as " + id + " at @s anchored eyes positioned ^ ^ ^" + d + " ";
			String hit = "as @e[distance=..2,type=!minecraft:item,type=!minecraft:experience_orb] run ";
			run(at + "run particle minecraft:soul_fire_flame ~ ~ ~ 0.2 0.2 0.2 0.02 8 force");
			run(at + "run particle minecraft:smoke ~ ~ ~ 0.2 0.2 0.2 0.01 4 force");
			run(at + hit + "damage @s 8 minecraft:wither_skull by " + id);
			run(at + hit + "effect give @s minecraft:wither 5 1 true");
		}
		return 100;
	}

	/** Sneak + right-click: a withering blast around you, and a shield for yourself. */
	private static int witheringBlast(ServerPlayerEntity p) {
		String id = p.getUuidAsString();
		String near = "@e[distance=0.1..8,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:area_effect_cloud]";
		run("execute as " + id + " at @s run playsound minecraft:entity.wither.ambient hostile @a ~ ~ ~ 3");
		run("execute as " + id + " at @s run particle minecraft:soul ~ ~1 ~ 2 1 2 0.05 80 force");
		run("execute as " + id + " at @s run particle minecraft:smoke ~ ~1 ~ 2 1 2 0.05 60 force");
		run("execute as " + id + " at @s as " + near + " run damage @s 6 minecraft:magic by " + id);
		run("execute as " + id + " at @s run effect give " + near + " minecraft:wither 8 1 true");
		run("effect give " + id + " minecraft:absorption 12 2 true");
		run("effect give " + id + " minecraft:resistance 6 0 true");
		return 500;
	}
}
