package com.example.maceupgrade;

import java.util.ArrayList;
import java.util.List;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

/**
 * Abilities. Each upgrade adds new ones and keeps the old ones.
 *
 *   Tier 1 Copper:    Right-click = Leap. Held: Speed I
 *   Tier 2 Iron:      Sneak + right-click = Dash. Held: Resistance I. Hit: Slowness
 *   Tier 3 Golden:    Held: Strength I. Hit: Weakness
 *   Tier 4 Diamond:   Held: Jump Boost II. Hit: Glowing + Blindness, Lifesteal
 *   Tier 5 Netherite: Held: Regeneration I. Hit: Wither. Kill: bans the player
 *                     (the ban itself is in MaceUpgradeMod)
 */
public final class MaceAbilities {
	private MaceAbilities() {}

	public static void register() {
		// Passive effects, refreshed once per second.
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			if (server.getTicks() % 20 != 0) {
				return;
			}
			for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
				int tier = getTier(player.getMainHandStack());
				if (tier <= 0) {
					continue;
				}
				give(player, StatusEffects.SPEED, 0);
				if (tier >= 2) give(player, StatusEffects.RESISTANCE, 0);
				if (tier >= 3) give(player, StatusEffects.STRENGTH, 0);
				if (tier >= 4) give(player, StatusEffects.JUMP_BOOST, 1);
				if (tier >= 5) give(player, StatusEffects.REGENERATION, 0);
			}
		});

		// On-hit abilities: only when the mace itself deals the damage.
		ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
			if (source.getAttacker() instanceof ServerPlayerEntity attacker
				&& source.getSource() == attacker
				&& entity != attacker) {
				int tier = getTier(attacker.getMainHandStack());
				if (tier >= 2) entity.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 40, 0));
				if (tier >= 3) entity.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 80, 0));
				if (tier >= 4) {
					entity.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, 100, 0));
					entity.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 40, 0));
					attacker.heal(amount * 0.2f); // lifesteal
				}
				if (tier >= 5) entity.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 80, 0));
			}
			return true;
		});

		// Active abilities: right-click = Leap, sneak + right-click = Dash (tier 2+).
		UseItemCallback.EVENT.register((player, world, hand) -> {
			if (hand != Hand.MAIN_HAND || !(player instanceof ServerPlayerEntity serverPlayer)) {
				return ActionResult.PASS;
			}
			ItemStack stack = serverPlayer.getMainHandStack();
			int tier = getTier(stack);
			if (tier <= 0 || serverPlayer.getItemCooldownManager().isCoolingDown(stack)) {
				return ActionResult.PASS;
			}
			if (serverPlayer.isSneaking() && tier >= 2) {
				Vec3d look = serverPlayer.getRotationVector();
				serverPlayer.setVelocity(look.x * 1.8, Math.max(look.y * 1.8, 0.3), look.z * 1.8);
				serverPlayer.playSound(SoundEvents.ENTITY_ENDER_DRAGON_FLAP, 1.0f, 1.2f);
			} else {
				Vec3d v = serverPlayer.getVelocity();
				serverPlayer.setVelocity(v.x, 0.9 + 0.15 * tier, v.z);
				serverPlayer.playSound(SoundEvents.ENTITY_BREEZE_JUMP, 1.0f, 1.0f);
			}
			serverPlayer.networkHandler.sendPacket(new EntityVelocityUpdateS2CPacket(serverPlayer));
			serverPlayer.fallDistance = 0;
			serverPlayer.getItemCooldownManager().set(stack, 100 - tier * 10);
			return ActionResult.SUCCESS;
		});
	}

	private static void give(ServerPlayerEntity player,
							 net.minecraft.registry.entry.RegistryEntry<net.minecraft.entity.effect.StatusEffect> effect,
							 int amplifier) {
		player.addStatusEffect(new StatusEffectInstance(effect, 60, amplifier, true, false, true));
	}

	/** Reads the upgrade tier stored on a mace (0 if it is not an upgraded mace). */
	public static int getTier(ItemStack stack) {
		if (!stack.isOf(Items.MACE)) {
			return 0;
		}
		NbtComponent data = stack.get(DataComponentTypes.CUSTOM_DATA);
		if (data == null) {
			return 0;
		}
		return data.copyNbt().getInt("mace_tier", 0);
	}

	/** Short ability descriptions for the item lore. */
	public static List<String> describe(int tier) {
		List<String> lines = new ArrayList<>();
		if (tier >= 1) lines.add("Right-click: Leap | Held: Speed I");
		if (tier >= 2) lines.add("Sneak + right-click: Dash | Held: Resistance I");
		if (tier >= 2) lines.add("Hit: Slowness");
		if (tier >= 3) lines.add("Held: Strength I | Hit: Weakness");
		if (tier >= 4) lines.add("Held: Jump Boost II | Hit: Glowing + Blindness + Lifesteal");
		if (tier >= 5) lines.add("Held: Regeneration I | Hit: Wither");
		if (tier >= 5) lines.add("Kill: bans the player");
		return lines;
	}
}
