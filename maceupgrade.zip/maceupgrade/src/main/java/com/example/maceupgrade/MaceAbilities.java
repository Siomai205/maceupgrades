package com.example.maceupgrade;

import java.util.ArrayList;
import java.util.List;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public final class MaceAbilities {
    private MaceAbilities() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTicks() % 20 != 0) return;
            for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                int tier = getTier(player.getMainHandStack());
                if (tier <= 0 || tier >= 10) continue;
                give(player, StatusEffects.SPEED, 0);
                if (tier >= 2) give(player, StatusEffects.RESISTANCE, 0);
                if (tier >= 3) give(player, StatusEffects.STRENGTH, 0);
                if (tier >= 4) give(player, StatusEffects.JUMP_BOOST, 1);
                if (tier >= 5) give(player, StatusEffects.REGENERATION, 0);
            }
        });

        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (source.getAttacker() instanceof ServerPlayerEntity attacker && source.getSource() == attacker && entity != attacker) {
                ItemStack held = attacker.getMainHandStack();
                int tier = getTier(held);
                if (tier >= 2 && tier < 10) entity.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 40, 0));
                if (tier >= 3 && tier < 10) entity.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 80, 0));
                if (tier >= 4 && tier < 10) {
                    entity.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, 100, 0));
                    entity.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 40, 0));
                    attacker.heal(amount * 0.2f);
                }
                if (tier >= 5 && tier < 10) entity.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 80, 0));
                if (held.isOf(MaceUpgradeMod.WARDEN_MACE)) {
                    entity.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 100, 0));
                    attacker.heal(amount * 0.12f);
                } else if (held.isOf(MaceUpgradeMod.ENDER_MACE)) {
                    entity.addStatusEffect(new StatusEffectInstance(StatusEffects.LEVITATION, 30, 0));
                } else if (held.isOf(MaceUpgradeMod.NETHER_MACE)) {
                    entity.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 120, 1));
                    entity.setOnFireFor(4);
                }
            }
            return true;
        });

        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (hand != Hand.MAIN_HAND || !(player instanceof ServerPlayerEntity p)) return ActionResult.PASS;
            ItemStack stack = p.getMainHandStack();
            boolean special = stack.isOf(MaceUpgradeMod.WARDEN_MACE) || stack.isOf(MaceUpgradeMod.ENDER_MACE) || stack.isOf(MaceUpgradeMod.NETHER_MACE);
            int tier = getTier(stack);
            if ((!special && tier <= 0) || p.getItemCooldownManager().isCoolingDown(stack)) return ActionResult.PASS;

            if (stack.isOf(MaceUpgradeMod.WARDEN_MACE)) {
                shockwave(p);
                p.playSound(SoundEvents.ENTITY_WARDEN_SONIC_BOOM, 1.0f, 1.0f);
                p.getItemCooldownManager().set(stack, 160);
            } else if (stack.isOf(MaceUpgradeMod.ENDER_MACE)) {
                if (p.isSneaking()) {
                    Vec3d look = p.getRotationVector();
                    p.requestTeleport(p.getX() + look.x * 8, p.getY() + look.y * 8, p.getZ() + look.z * 8);
                } else {
                    dragonBurst(p);
                }
                p.playSound(SoundEvents.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.0f);
                p.getItemCooldownManager().set(stack, 120);
            } else if (stack.isOf(MaceUpgradeMod.NETHER_MACE)) {
                witherBurst(p);
                p.playSound(SoundEvents.ENTITY_WITHER_SHOOT, 1.0f, 0.8f);
                p.getItemCooldownManager().set(stack, 160);
            } else {
                Vec3d v = p.getVelocity();
                if (p.isSneaking() && tier >= 2) {
                    Vec3d look = p.getRotationVector();
                    p.setVelocity(look.x * 1.8, Math.max(look.y * 1.8, 0.3), look.z * 1.8);
                } else {
                    p.setVelocity(v.x, 0.9 + 0.15 * tier, v.z);
                }
                p.networkHandler.sendPacket(new EntityVelocityUpdateS2CPacket(p));
                p.fallDistance = 0;
                p.playSound(SoundEvents.ENTITY_BREEZE_JUMP, 1.0f, 1.0f);
                p.getItemCooldownManager().set(stack, 100 - tier * 10);
            }
            return ActionResult.SUCCESS;
        });
    }

    private static void shockwave(ServerPlayerEntity player) {
        if (!(player.getWorld() instanceof ServerWorld world)) return;
        for (var entity : world.getOtherEntities(player, player.getBoundingBox().expand(7.0), e -> e instanceof LivingEntity)) {
            LivingEntity target = (LivingEntity) entity;
            target.damage(world, world.getDamageSources().sonicBoom(player), 10.0f);
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 100, 0));
            Vec3d push = target.getPos().subtract(player.getPos()).normalize().multiply(1.2);
            target.addVelocity(push.x, 0.45, push.z);
        }
    }

    private static void dragonBurst(ServerPlayerEntity player) {
        if (!(player.getWorld() instanceof ServerWorld world)) return;
        Vec3d center = player.getPos().add(player.getRotationVector().multiply(5));
        for (var entity : world.getOtherEntities(player, new Box(center.x-3, center.y-2, center.z-3, center.x+3, center.y+2, center.z+3), e -> e instanceof LivingEntity)) {
            LivingEntity target = (LivingEntity) entity;
            target.damage(world, world.getDamageSources().magic(), 8.0f);
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 100, 0));
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.LEVITATION, 30, 0));
        }
    }

    private static void witherBurst(ServerPlayerEntity player) {
        if (!(player.getWorld() instanceof ServerWorld world)) return;
        for (var entity : world.getOtherEntities(player, player.getBoundingBox().expand(5.0), e -> e instanceof LivingEntity)) {
            LivingEntity target = (LivingEntity) entity;
            target.damage(world, world.getDamageSources().wither(), 7.0f);
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 160, 1));
            target.setOnFireFor(3);
        }
    }

    private static void give(ServerPlayerEntity player, net.minecraft.registry.entry.RegistryEntry<net.minecraft.entity.effect.StatusEffect> effect, int amplifier) {
        player.addStatusEffect(new StatusEffectInstance(effect, 60, amplifier, true, false, true));
    }

    public static int getTier(ItemStack stack) {
        if (stack.isOf(MaceUpgradeMod.WARDEN_MACE)) return 10;
        if (stack.isOf(MaceUpgradeMod.ENDER_MACE)) return 20;
        if (stack.isOf(MaceUpgradeMod.NETHER_MACE)) return 30;
        if (!stack.isOf(Items.MACE)) return 0;
        NbtComponent data = stack.get(DataComponentTypes.CUSTOM_DATA);
        return data == null ? 0 : data.copyNbt().getInt("mace_tier", 0);
    }

    public static List<String> describe(int tier) {
        List<String> lines = new ArrayList<>();
        if (tier >= 1) lines.add("Right-click: Leap | Held: Speed I");
        if (tier >= 2) lines.add("Sneak + right-click: Dash | Held: Resistance I");
        if (tier >= 2) lines.add("Hit: Slowness");
        if (tier >= 3) lines.add("Held: Strength I | Hit: Weakness");
        if (tier >= 4) lines.add("Held: Jump Boost II | Hit: Glowing + Blindness + Lifesteal");
        if (tier >= 5) lines.add("Held: Regeneration I | Hit: Wither");
        return lines;
    }
}
