package com.example.maceupgrade;

import com.mojang.brigadier.Command;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;

public class DummyCommand {
    public static void registerCommands() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(Commands.literal("maceupgrade")
                .executes(context -> {
                    context.getSource().sendSuccess(() -> Component.literal("MaceUpgrade mod is running on Minecraft 26.3!"), false);
                    return Command.SINGLE_SUCCESS;
                })
            );
        });
    }
}
