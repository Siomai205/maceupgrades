package com.example.maceupgrade;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MaceUpgradeMod implements ModInitializer {
    public static final String MOD_ID = "maceupgrade";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Initializing Mace Upgrade Mod for Minecraft 26.3");
        ThemedMaces.registerMaces();
        MaceAbilities.registerAbilities();
        DummyCommand.registerCommands();
    }
}
