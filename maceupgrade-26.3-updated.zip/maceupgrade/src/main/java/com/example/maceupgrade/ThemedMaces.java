package com.example.maceupgrade;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.MaceItem;

public class ThemedMaces {
    public static final Item MACE_TIER_1 = register("mace_tier_1", new MaceItem(new Item.Properties().durability(300)));
    public static final Item MACE_TIER_2 = register("mace_tier_2", new MaceItem(new Item.Properties().durability(500)));
    public static final Item MACE_TIER_3 = register("mace_tier_3", new MaceItem(new Item.Properties().durability(800)));
    public static final Item MACE_TIER_4 = register("mace_tier_4", new MaceItem(new Item.Properties().durability(1200)));
    public static final Item MACE_TIER_5 = register("mace_tier_5", new MaceItem(new Item.Properties().durability(1800)));
    public static final Item NETHER_MACE = register("nether_mace", new MaceItem(new Item.Properties().durability(1500).fireResistant()));
    public static final Item ENDER_MACE = register("ender_mace", new MaceItem(new Item.Properties().durability(1600)));
    public static final Item WARDEN_MACE = register("warden_mace", new MaceItem(new Item.Properties().durability(2500).fireResistant()));

    private static Item register(String name, Item item) {
        return Registry.register(BuiltInRegistries.ITEM, ResourceLocation.fromNamespaceAndPath(MaceUpgradeMod.MOD_ID, name), item);
    }

    public static void registerMaces() {
        MaceUpgradeMod.LOGGER.info("Registering themed maces for 26.3");
    }
}
