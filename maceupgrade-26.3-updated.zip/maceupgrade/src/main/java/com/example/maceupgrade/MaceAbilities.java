package com.example.maceupgrade;

import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

public class MaceAbilities {
    public static void registerAbilities() {
        UseItemCallback.EVENT.register((player, world, hand) -> {
            var stack = player.getItemInHand(hand);
            if (!world.isClientSide() && stack.is(ThemedMaces.WARDEN_MACE)) {
                player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 200, 1, false, false));
            }
            return InteractionResultHolder.pass(stack);
        });
    }
}
